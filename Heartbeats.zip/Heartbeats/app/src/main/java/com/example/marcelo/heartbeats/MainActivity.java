package com.example.marcelo.heartbeats;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Handler Customhandler = new Handler();

     int heartbeat = 0;
    final Runnable mainprocess = new Runnable() { //atividade em segundo plano após botão "começar"

        int Hbrate;
        int lastHbrate = 0;
        int idade = R.id.inputidade;
        long startTime = System.currentTimeMillis();
        long endTime = startTime + 10000;
        long checktime = 0;


        @Override
        public void run() {
         TextView tv = (TextView)findViewById(R.id.count);
         tv.setText(""+heartbeat);


        if (checktime>=endTime){
            startTime=System.currentTimeMillis();
            Hbrate = heartbeat * 6;
            endTime=startTime+10000;

        }
            if (Hbrate>0) {
                lastHbrate = Hbrate;
                TextView tv2 = (TextView) findViewById( R.id.count2 );
                tv2.setText( "" + lastHbrate );
                Hbrate = 0;
                heartbeat = 0;


                //menores de 01 ano
                if (idade <= 1) {
                    if (lastHbrate >= 80 && lastHbrate <= 140) {
                        TextView tvresultado = (TextView) findViewById( R.id.resultado );
                        tvresultado.setText( "normal" );
                    } else {
                        TextView tvresultado = (TextView) findViewById( R.id.resultado );
                        tvresultado.setText( "Batimentos cardiacos fora do normal, consulte um médico! " );
                    }
                }
                //entre 01 ano e 02 anos
                if (idade >= 1 && idade <= 2) {
                    if (lastHbrate >= 80 && lastHbrate <= 130) {
                        TextView tvresultado = (TextView) findViewById( R.id.resultado );
                        tvresultado.setText( "normal" );
                    } else {
                        TextView tvresultado = (TextView) findViewById( R.id.resultado );
                        tvresultado.setText( "Batimentos cardiacos fora do normal, consulte um médico! " );
                    }
                }
                //entre 02 anos e 06 anos
                if (idade >= 3 && idade <= 6) {
                    if (lastHbrate >= 75 && lastHbrate <= 120) {
                        TextView tvresultado = (TextView) findViewById( R.id.resultado );
                        tvresultado.setText( "normal" );
                    } else {
                        TextView tvresultado = (TextView) findViewById( R.id.resultado );
                        tvresultado.setText( "Batimentos cardiacos fora do normal, consulte um médico! " );
                    }
                }
                //entre 07 anos e 12 anos
                if (idade >= 7 && idade <= 12) {
                    if (lastHbrate >= 75 && lastHbrate <= 110) {
                        TextView tvresultado = (TextView) findViewById( R.id.resultado );
                        tvresultado.setText( "normal" );
                    } else {
                        TextView tvresultado = (TextView) findViewById( R.id.resultado );
                        tvresultado.setText( "Batimentos cardiacos fora do normal, consulte um médico! " );
                    }
                }
                //entre 13 anos e 18 anos
                if (idade >= 13 && idade <= 18) {
                    if (lastHbrate >= 70 && lastHbrate <= 110) {
                        TextView tvresultado = (TextView) findViewById( R.id.resultado );
                        tvresultado.setText( "normal" );
                    } else {
                        TextView tvresultado = (TextView) findViewById( R.id.resultado );
                        tvresultado.setText( "Batimentos cardiacos fora do normal, consulte um médico! " );
                    }
                }
                //acima de 18 anos
                if (idade >= 19) {
                    if (lastHbrate >= 60 && lastHbrate <= 110) {
                        TextView tvresultado = (TextView) findViewById( R.id.resultado );
                        tvresultado.setText( "normal" );
                    } else {
                        TextView tvresultado = (TextView) findViewById( R.id.resultado );
                        tvresultado.setText( "Batimentos cardiacos fora do normal, consulte um médico! " );
                    }
                }
            }
            Customhandler.postDelayed( this,120 );
        }

    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        //fab.setOnClickListener(new View.OnClickListener() {
           // @Override
          //  public void onClick(View view) {
             //   Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                     //   .setAction("Action", null).show();
           // }
       // });

        Button btnstart =  (Button)findViewById(R.id.btnstart);
        btnstart.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Customhandler.postDelayed(mainprocess,0);

            }
        });
    }


    public boolean onKeyDown (int Keycode, KeyEvent event){

        switch (Keycode){
            case KeyEvent.KEYCODE_1:
                Toast.makeText(getApplicationContext(), "key 1 pressed", Toast.LENGTH_SHORT).show();
                heartbeat++;
                if (heartbeat>0){

                }

                return true;
            case KeyEvent.KEYCODE_ENTER:
                //????
                return true;

        }
        return super.onKeyDown(Keycode, event);
    }


  //  @Override
   // public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
      //  getMenuInflater().inflate(R.menu.menu_main, menu);
     //   return true;
   // }

    //@Override
  //  public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
      //  int id = item.getItemId();

        //noinspection SimplifiableIfStatement
       // if (id == R.id.action_settings) {
            //return true;
        //}

       // return super.onOptionsItemSelected(item);
   // }


}